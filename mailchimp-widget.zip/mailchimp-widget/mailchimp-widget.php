<?php
/*
    Plugin Name: Mailchimp widget
    Plugin URI: http://www.enovathemes.com
    Description: Mailchimp subscribe widget
    Author: Enovathemes
    Version: 1.0
    Author URI: http://enovathemes.com
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

define('MAILCHIMP_API', 'caa6f34b24e11856eedec90bc997a068-us12-my-fake-api'); // change yo your own API KEY

function register_mailchimp_script(){
	wp_register_script( 'widget-mailchimp', plugins_url('/js/widget-mailchimp.js', __FILE__ ), array('jquery'), '', true);
	wp_register_style('widget-mailchimp', plugins_url('/css/widget-mailchimp.css', __FILE__ ));
}

add_action( 'wp_enqueue_scripts', 'register_mailchimp_script' );

function mailchimp_connect( $url, $api_key, $data = array() ) {

    $url .= '?' . http_build_query($data);

    $mailchimp = curl_init();

    $headers = array(
		'Content-Type: application/json',
		'Authorization: Basic '.base64_encode( 'user:'. $api_key )
	);

	curl_setopt($mailchimp, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($mailchimp, CURLOPT_URL, $url );
	curl_setopt($mailchimp, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($mailchimp, CURLOPT_CUSTOMREQUEST, 'GET');
	curl_setopt($mailchimp, CURLOPT_TIMEOUT, 10);
	curl_setopt($mailchimp, CURLOPT_USERAGENT, 'PHP-MCAPI/2.0');
	curl_setopt($mailchimp, CURLOPT_SSL_VERIFYPEER, false);

    return curl_exec($mailchimp);
}

function mailchimp_post( $email, $status, $list_id, $api_key, $merge_fields = array('FNAME' => '','LNAME' => '') ){

    $data = array(
        'apikey'        => $api_key,
        'email_address' => $email,
        'status'        => $status,
        'merge_fields'  => $merge_fields
    );

    $url = 'https://' . substr($api_key,strpos($api_key,'-')+1) . '.api.mailchimp.com/3.0/lists/' . $list_id . '/members/' . md5(strtolower($data['email_address']));

    $headers = array(
    	'Content-Type: application/json', 
    	'Authorization: Basic '.base64_encode( 'user:'.$api_key )
	);

    $$mailchimp = curl_init();
 
    curl_setopt($$mailchimp, CURLOPT_URL, $url);
    curl_setopt($$mailchimp, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($$mailchimp, CURLOPT_RETURNTRANSFER, true); 
    curl_setopt($$mailchimp, CURLOPT_CUSTOMREQUEST, 'PUT');
    curl_setopt($$mailchimp, CURLOPT_TIMEOUT, 10);
    curl_setopt($$mailchimp, CURLOPT_POST, true);
    curl_setopt($$mailchimp, CURLOPT_POSTFIELDS, json_encode($data) );
    curl_setopt($$mailchimp, CURLOPT_USERAGENT, 'PHP-MCAPI/2.0');
    curl_setopt($$mailchimp, CURLOPT_SSL_VERIFYPEER, false);
 
    return curl_exec($$mailchimp);
}

function mailchimp_list() {

    $api_key = MAILCHIMP_API;

    if (empty($api_key)) {
        return new WP_Error( 'no_api_key', esc_html__( 'No Mailchimp API key is found.', 'mailchimp' ) );
    }
     

    if ( false === ( $mailchimp_list = get_transient( 'mailchimp-' . $api_key ) ) ) {

        $data = array(
            'fields' => 'lists',
            'count' => 'all',
        );
         
        $result = json_decode( mailchimp_connect( $url, 'GET', $api_key, $data) );
       
        if (! $result ) {
            return new WP_Error( 'bad_json', esc_html__( 'Mailchimp has returned invalid data.', 'mailchimp' ) );
        }

        if ( !empty( $result->lists ) ) {
            foreach( $result->lists as $list ){
                $mailchimp_list[] = array(
                    'id'      => $list->id,
                    'name'    => $list->name,
                );
            }
        } else {
            return new WP_Error( 'no_list', esc_html__( 'Mailchimp did not return any list.', 'mailchimp' ) );
        }

        // do not set an empty transient - should help catch private or empty accounts.
        if ( ! empty( $mailchimp_list ) ) {
            $mailchimp_list = base64_encode( serialize( $mailchimp_list ) );
            set_transient( 'mailchimp-' . $api_key, $mailchimp_list, apply_filters( 'null_mailchimp_cache_time', WEEK_IN_SECONDS * 2 ) );
        }
    }

    if ( ! empty( $mailchimp_list ) ) {
        return unserialize( base64_decode( $mailchimp_list ) );
    } else {
        return new WP_Error( 'no_list', esc_html__( 'Mailchimp did not return any list.', 'mailchimp' ) );
    }
}

function mailchimp_action(){

    if ( ! isset( $_POST['et_mailchimp_nonce'] ) || !wp_verify_nonce( $_POST['et_mailchimp_nonce'], 'et_mailchimp_action' )) {
       exit;
    } else {

        $email     = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
        $fname     = strip_tags(trim($_POST["fname"]));
        $lname     = strip_tags(trim($_POST["lname"]));
        $list      = strip_tags(trim($_POST["list"]));
        $api_key   = MAILCHIMP_API;

        mailchimp_post($email, 'subscribed', $list, $api_key, array('FNAME' => $fname,'LNAME' => $lname) );
        
        die;
    }
}
add_action('admin_post_nopriv_et_mailchimp', 'mailchimp_action');
add_action('admin_post_et_mailchimp', 'mailchimp_action');

add_action('widgets_init', 'register_mailchimp_widget');
function register_mailchimp_widget(){
	register_widget( 'WP_Widget_Mailchimp' );
}

class  WP_Widget_Mailchimp extends WP_Widget {

	public function __construct() {
		parent::__construct(
			'mailchimp',
			esc_html__('* Mailchimp', 'mailchimp'),
			array( 'description' => esc_html__('Mailchimp subscribe widget', 'mailchimp'))
		);
	}

	public function widget( $args, $instance ) {

		wp_enqueue_style('widget-mailchimp');
		wp_enqueue_script('widget-mailchimp');

		extract($args);


		$title  = apply_filters( 'widget_title', $instance['title'] );
		$list   = $instance['list'] ? esc_attr($instance['list']) : '';

		$output = "";
		$output .= $before_widget;
		$output .='<div class="mailchimp-form">';
			if ( ! empty( $title ) ){$output .= $before_title . $title . $after_title;}
			
			$output .='<form class="et-mailchimp-form" name="et-mailchimp-form" action="'.esc_url( admin_url('admin-post.php') ).'" method="POST">';
				$output .='<input type="text" value="" name="fname" placeholder="'.esc_html__("First name", 'mailchimp').'">';
				$output .='<input type="text" value="" name="lname" placeholder="'.esc_html__("Last name", 'mailchimp').'">';
				$output .='<div>';
					$output .='<input type="text" value="" name="email" placeholder="'.esc_html__("Email", 'mailchimp').'">';
					$output .='<span class="alert warning">'.esc_html__('Invalid or empty email', 'mailchimp').'</span>';
				$output .= '</div>';
				
				$output .='<div class="send-div">';
			    	$output .='<input type="submit" class="button" value="'.esc_html__('Subscribe', 'mailchimp').'" name="subscribe">';
					$output .='<div class="sending"></div>';
				$output .='</div>';

			    $output .='<div class="et-mailchimp-success alert final success">'.esc_html__('You have successfully subscribed to the newsletter.', 'mailchimp').'</div>';
		        $output .='<div class="et-mailchimp-error alert final error">'.esc_html__('Something went wrong. Your subscription failed.', 'mailchimp').'</div>';
		        
		        $output .='<input type="hidden" value="'.$list.'" name="list">';
				$output .='<input type="hidden" name="action" value="et_mailchimp" />';
				$output .= wp_nonce_field( "et_mailchimp_action", "et_mailchimp_nonce", false, false );

			$output .='</form>';
		$output .='</div>';
		$output .= $after_widget;
		echo $output;
	}

 	public function form( $instance ) {

		$defaults = array(
 			'title' => esc_html__('Subscribe', 'mailchimp'),
 			'list'  => '',
 		);

 		$instance = wp_parse_args((array) $instance, $defaults);

 		$list_array = mailchimp_list();

 		?>

			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php echo esc_html__( 'Title:', 'mailchimp' ); ?></label> 
				<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr($instance['title']); ?>" />
			</p>

			<?php if ( is_wp_error( $list_array ) ): ?>
				<p><?php echo wp_kses_post( $list_array->get_error_message() ); ?></p>
			<?php else: ?>
				<p>
					<label for="<?php echo $this->get_field_id( 'list' ); ?>"><?php echo esc_html__( 'List:', 'mailchimp' ); ?></label> 
					<select class="widefat" id="<?php echo $this->get_field_id( 'list' ); ?>" name="<?php echo $this->get_field_name( 'list' ); ?>" >
					<?php foreach ( $list_array as $list ) { ?>
						<option value="<?php echo $list['id']; ?>" <?php selected( $instance['list'], $list['id'] ); ?>><?php echo $list['name']; ?></option>
					<?php } ?>
					</select>
				</p>
			<?php endif; ?>
		
	<?php }

	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['list']  = strip_tags( $new_instance['list']);
		return $instance;
	}
}

?>